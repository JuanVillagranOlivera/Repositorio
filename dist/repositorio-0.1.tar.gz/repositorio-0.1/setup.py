from setuptools import setup, find_packages

setup(
    name='Repositorio',
    version='0.1',
    packages=find_packages(),
    author='Juan Villagran',
    author_email='juan.villagran@insodev.cl',
    url='https://github.com/JuanVillagranOlivera/Repositorio',
)